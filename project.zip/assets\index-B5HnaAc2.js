(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e={uz:{nav_home:`Bosh sahifa`,nav_services:`Xizmatlar`,nav_prices:`Narxlar`,nav_staff:`Xodimlar`,nav_booking:`Bron qilish`,nav_admin:`Admin`,nav_login:`Kirish / Ro'yxatdan o'tish`,nav_logout:`Chiqish`,nav_profile:`Profil`,auth_login_tab:`Kirish`,auth_register_tab:`Ro'yxatdan o'tish`,auth_role_worker:`Ishchi`,auth_role_client:`Klient`,auth_name:`Ism familiya`,auth_phone:`Telefon raqam`,auth_exp:`Staj (xodimlar uchun)`,auth_register_btn:`Ro'yxatdan o'tish`,hero_title:`Bolalar va Ayollar`,hero_title2:`Massaj Markazi`,hero_subtitle:`Farzandingiz va sizning sog'liqingiz uchun professional massaj xizmatlari`,hero_btn_book:`Bron qilish`,hero_btn_services:`Xizmatlar`,hero_stat_clients:`Mijozlar`,hero_stat_workers:`Mutaxassislar`,hero_stat_years:`Yil tajriba`,services_title:`Bizning xizmatlar`,services_subtitle:`Farzandingiz va siz uchun eng yaxshi massaj xizmatlari`,service_baby_title:`Bolalar massaji`,service_baby_desc:`2 oylikdan 6 yoshgacha bo'lgan bolalar uchun professional massaj. Rivojlanishni tezlashtiradi va sog'liqni mustahkamlaydi.`,service_women_title:`Ayollar massaji`,service_women_desc:`Ayollar uchun maxsus ishlab chiqilgan massaj turlari. Charchashni kamaytiradi, tanani tiklaydi.`,prices_title:`Narxlar ro'yxati`,prices_subtitle:`Barcha narxlar kuniga hisoblanadi`,prices_baby:`Bolalar massaji`,prices_women:`Ayollar massaji`,price_currency:`so'm`,price_per_day:`/ kun`,staff_title:`Bizning mutaxassislar`,staff_subtitle:`Tajribali va mehribon mutaxassislarimiz`,staff_free:`Bo'sh`,staff_busy:`Band`,staff_experience:`yil tajriba`,staff_book:`Bron qilish`,booking_title:`Bron qilish`,booking_subtitle:`Qulay vaqtni tanlang`,booking_select_worker:`Mutaxassis tanlang`,booking_select_time:`Vaqt tanlang`,booking_your_name:`Ismingiz`,booking_your_phone:`Telefon raqamingiz`,booking_confirm:`Bron qilish`,booking_success:`Bron muvaffaqiyatli amalga oshirildi!`,booking_no_slots:`Bu mutaxassis uchun bo'sh vaqt yo'q`,booking_fill_all:`Barcha maydonlarni to'ldiring`,login_title:`Tizimga kirish`,login_username:`Foydalanuvchi nomi`,login_password:`Parol`,login_btn:`Kirish`,login_error:`Noto'g'ri login yoki parol`,profile_title:`Mening profilim`,profile_name:`Ism va familiya`,profile_experience:`Ish staji (yil)`,profile_status:`Holat`,profile_upload_photo:`Rasm yuklash`,profile_save:`Saqlash`,profile_saved:`Saqlandi!`,profile_timeslots:`Ish vaqtlari`,profile_add_slot:`Vaqt qo'shish`,profile_slot_date:`Sana`,profile_slot_time:`Vaqt`,profile_slot_enable:`Faol`,profile_slot_disable:`Nofaol`,profile_bookings:`Bronlar`,admin_title:`Admin panel`,admin_workers:`Xodimlar`,admin_bookings:`Barcha bronlar`,admin_add_worker:`Xodim qo'shish`,admin_edit:`Tahrirlash`,admin_delete:`O'chirish`,admin_confirm_delete:`Haqiqatan o'chirishni xohlaysizmi?`,admin_name:`Ism`,admin_username:`Login`,admin_password:`Parol`,admin_experience:`Staj`,admin_status:`Holat`,admin_save:`Saqlash`,admin_cancel:`Bekor qilish`,admin_client:`Mijoz`,admin_phone:`Telefon`,admin_worker:`Mutaxassis`,admin_date:`Sana/Vaqt`,admin_no_bookings:`Bronlar yo'q`,free:`Bo'sh`,busy:`Band`,close:`Yopish`,footer_text:`© 2025 BabyMassage Markazi. Barcha huquqlar himoyalangan.`,footer_contact:`Bog'lanish`,footer_address:`Sputnik 16a 21 dom`,footer_phone:`+998 99 879 06 76`,footer_hours:`Ish vaqti: 9:00 - 18:00`},ru:{nav_home:`Главная`,nav_services:`Услуги`,nav_prices:`Цены`,nav_staff:`Специалисты`,nav_booking:`Запись`,nav_admin:`Админ`,nav_login:`Войти`,nav_logout:`Выйти`,nav_profile:`Профиль`,hero_title:`Детский и женский`,hero_title2:`Центр массажа`,hero_subtitle:`Профессиональные услуги массажа для вашего ребёнка и вас`,hero_btn_book:`Записаться`,hero_btn_services:`Услуги`,hero_stat_clients:`Клиентов`,hero_stat_workers:`Специалистов`,hero_stat_years:`Лет опыта`,services_title:`Наши услуги`,services_subtitle:`Лучшие услуги массажа для вашего ребёнка и вас`,service_baby_title:`Детский массаж`,service_baby_desc:`Профессиональный массаж для детей от 2 месяцев до 6 лет. Ускоряет развитие и укрепляет здоровье.`,service_women_title:`Женский массаж`,service_women_desc:`Специально разработанные виды массажа для женщин. Снимает усталость, восстанавливает тело.`,prices_title:`Прейскурант`,prices_subtitle:`Все цены указаны за день`,prices_baby:`Детский массаж`,prices_women:`Женский массаж`,price_currency:`сум`,price_per_day:`/ день`,staff_title:`Наши специалисты`,staff_subtitle:`Опытные и заботливые специалисты`,staff_free:`Свободен`,staff_busy:`Занят`,staff_experience:`лет опыта`,staff_book:`Записаться`,booking_title:`Запись на приём`,booking_subtitle:`Выберите удобное время`,booking_select_worker:`Выберите специалиста`,booking_select_time:`Выберите время`,booking_your_name:`Ваше имя`,booking_your_phone:`Номер телефона`,booking_confirm:`Записаться`,booking_success:`Запись успешно оформлена!`,booking_no_slots:`Нет свободного времени для этого специалиста`,booking_fill_all:`Заполните все поля`,login_title:`Вход в систему`,login_username:`Имя пользователя`,login_password:`Пароль`,login_btn:`Войти`,login_error:`Неверный логин или пароль`,profile_title:`Мой профиль`,profile_name:`Имя и фамилия`,profile_experience:`Стаж работы (лет)`,profile_status:`Статус`,profile_upload_photo:`Загрузить фото`,profile_save:`Сохранить`,profile_saved:`Сохранено!`,profile_timeslots:`Рабочее время`,profile_add_slot:`Добавить время`,profile_slot_date:`Дата`,profile_slot_time:`Время`,profile_slot_enable:`Активно`,profile_slot_disable:`Неактивно`,profile_bookings:`Записи`,admin_title:`Панель администратора`,admin_workers:`Сотрудники`,admin_bookings:`Все записи`,admin_add_worker:`Добавить сотрудника`,admin_edit:`Редактировать`,admin_delete:`Удалить`,admin_confirm_delete:`Вы действительно хотите удалить?`,admin_name:`Имя`,admin_username:`Логин`,admin_password:`Пароль`,admin_experience:`Стаж`,admin_status:`Статус`,admin_save:`Сохранить`,admin_cancel:`Отмена`,admin_client:`Клиент`,admin_phone:`Телефон`,admin_worker:`Специалист`,admin_date:`Дата/Время`,admin_no_bookings:`Записей нет`,free:`Свободен`,busy:`Занят`,close:`Закрыть`,footer_text:`© 2025 BabyMassage Центр. Все права защищены.`,footer_contact:`Контакты`,footer_address:`Sputnik 16a 21 dom`,footer_phone:`+998 99 879 06 76`,footer_hours:`Часы работы: 9:00 - 18:00`},en:{nav_home:`Home`,nav_services:`Services`,nav_prices:`Prices`,nav_staff:`Staff`,nav_booking:`Booking`,nav_admin:`Admin`,nav_login:`Login`,nav_logout:`Logout`,nav_profile:`Profile`,hero_title:`Children & Women's`,hero_title2:`Massage Center`,hero_subtitle:`Professional massage services for your child and yourself`,hero_btn_book:`Book Now`,hero_btn_services:`Services`,hero_stat_clients:`Clients`,hero_stat_workers:`Specialists`,hero_stat_years:`Years Experience`,services_title:`Our Services`,services_subtitle:`The best massage services for your child and you`,service_baby_title:`Baby Massage`,service_baby_desc:`Professional massage for children aged 2 months to 6 years. Accelerates development and strengthens health.`,service_women_title:`Women's Massage`,service_women_desc:`Specially designed massage types for women. Reduces fatigue and restores the body.`,prices_title:`Price List`,prices_subtitle:`All prices are per day`,prices_baby:`Baby Massage`,prices_women:`Women's Massage`,price_currency:`UZS`,price_per_day:`/ day`,staff_title:`Our Specialists`,staff_subtitle:`Experienced and caring specialists`,staff_free:`Available`,staff_busy:`Busy`,staff_experience:`years experience`,staff_book:`Book`,booking_title:`Book Appointment`,booking_subtitle:`Choose a convenient time`,booking_select_worker:`Select Specialist`,booking_select_time:`Select Time`,booking_your_name:`Your Name`,booking_your_phone:`Phone Number`,booking_confirm:`Confirm Booking`,booking_success:`Booking successfully completed!`,booking_no_slots:`No available time slots for this specialist`,booking_fill_all:`Please fill in all fields`,login_title:`Login`,login_username:`Username`,login_password:`Password`,login_btn:`Login`,login_error:`Invalid username or password`,profile_title:`My Profile`,profile_name:`Full Name`,profile_experience:`Work Experience (years)`,profile_status:`Status`,profile_upload_photo:`Upload Photo`,profile_save:`Save`,profile_saved:`Saved!`,profile_timeslots:`Work Schedule`,profile_add_slot:`Add Time Slot`,profile_slot_date:`Date`,profile_slot_time:`Time`,profile_slot_enable:`Active`,profile_slot_disable:`Inactive`,profile_bookings:`Bookings`,admin_title:`Admin Panel`,admin_workers:`Workers`,admin_bookings:`All Bookings`,admin_add_worker:`Add Worker`,admin_edit:`Edit`,admin_delete:`Delete`,admin_confirm_delete:`Are you sure you want to delete?`,admin_name:`Name`,admin_username:`Username`,admin_password:`Password`,admin_experience:`Experience`,admin_status:`Status`,admin_save:`Save`,admin_cancel:`Cancel`,admin_client:`Client`,admin_phone:`Phone`,admin_worker:`Specialist`,admin_date:`Date/Time`,admin_no_bookings:`No bookings`,free:`Available`,busy:`Busy`,close:`Close`,footer_text:`© 2025 BabyMassage Center. All rights reserved.`,footer_contact:`Contact`,footer_address:`Sputnik 16a 21 dom`,footer_phone:`+998 99 879 06 76`,footer_hours:`Working hours: 9:00 - 18:00`}};function t(e){let t=new Date(e);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,`0`)}-${String(t.getDate()).padStart(2,`0`)}`}function n(e,n){let r=[],i=new Date(e);for(i.setHours(0,0,0,0);r.length<n;)i.getDay()!==0&&r.push(t(new Date(i))),i.setDate(i.getDate()+1);return r}function r(e){let t=new Date(e);t.setHours(0,0,0,0);let n=new Date;if(n.setHours(0,0,0,0),n<t)return 0;let r=0,i=new Date(t);for(;i<=n;)i.getDay()!==0&&r++,i.setDate(i.getDate()+1);return r}function i(e){let t=[`09:00`,`10:00`,`11:00`,`13:00`,`14:00`,`15:00`],r=n(e,10),i=[],a=Date.now();return r.forEach(e=>{t.forEach(t=>{i.push({id:a++,date:e,time:t,enabled:!0,booked:!1})})}),i}var a=t(new Date),o=[{id:1,name:`Shahnoza Rahimova`,username:`shahnoza`,password:`shahnoza123`,experience:5,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)},{id:2,name:`Dilofaruz Karimova`,username:`dilofaruz`,password:`dilofaruz123`,experience:7,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)},{id:3,name:`Dilafruz Nazarova`,username:`dilafruz1`,password:`dilafruz1_123`,experience:4,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)},{id:4,name:`Dilafruz Toshmatova`,username:`dilafruz2`,password:`dilafruz2_123`,experience:6,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)},{id:5,name:`Yulduz Usmonova`,username:`yulduz`,password:`yulduz123`,experience:8,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)},{id:6,name:`Dilnoza Mirzayeva`,username:`dilnoza`,password:`dilnoza123`,experience:3,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)}],s={id:0,name:`Admin`,username:`admin`,password:`admin123`,role:`admin`};function c(e){let n=new Date;n.setHours(0,0,0,0);let a=!1;return e.forEach(e=>{if(r(e.courseStartDate)>=10){let r=new Date(n);for(r.setDate(r.getDate()+1);r.getDay()===0;)r.setDate(r.getDate()+1);e.courseStartDate=t(r),e.timeSlots=i(r),e.status=`free`,a=!0}}),a}function l(){let e=localStorage.getItem(`workers`),t;return e?(t=JSON.parse(e),t.forEach(e=>{e.courseStartDate||(e.courseStartDate=a,(!e.timeSlots||e.timeSlots.length===0)&&(e.timeSlots=i(a)))})):t=o,(c(t)||!e)&&localStorage.setItem(`workers`,JSON.stringify(t)),t}function u(e){localStorage.setItem(`workers`,JSON.stringify(e))}function d(){let e=localStorage.getItem(`clients`);return e?JSON.parse(e):[]}function f(e){localStorage.setItem(`clients`,JSON.stringify(e))}function p(){let e=localStorage.getItem(`bookings`);return e?JSON.parse(e):[]}function m(e){localStorage.setItem(`bookings`,JSON.stringify(e))}function h(){let e=sessionStorage.getItem(`currentUser`);return e?JSON.parse(e):null}function g(e){e?sessionStorage.setItem(`currentUser`,JSON.stringify(e)):sessionStorage.removeItem(`currentUser`)}function _(e,t){if(e===s.username&&t===s.password)return g(s),s;let n=l().find(n=>n.username===e&&n.password===t);if(n)return g(n),n;let r=d().find(n=>n.username===e&&n.password===t);return r?(g(r),r):null}function v(e){let t=p(),n={...e,id:Date.now()};t.push(n),m(t);let r=l(),i=r.findIndex(t=>t.id===e.workerId);if(i!==-1){let t=r[i].timeSlots.findIndex(t=>t.id===e.slotId);t!==-1&&(r[i].timeSlots[t].booked=!0),u(r)}return n}function y({name:e,username:t,password:n,experience:r}){let o=l();if(o.find(e=>e.username===t))return null;let s={id:Date.now(),name:e,username:t,password:n,experience:parseInt(r)||0,status:`free`,photo:null,role:`worker`,courseStartDate:a,timeSlots:i(a)};return o.push(s),u(o),s}function b({name:e,phone:t,username:n,password:r}){let i=d();if(i.find(e=>e.username===n))return null;let a={id:Date.now(),name:e,phone:t,username:n,password:r,role:`client`};return i.push(a),f(i),a}function x(e){let t=n(e,10);return t[t.length-1]}function S(e){let t=r(e.courseStartDate);return Math.max(0,10-t)}var C=localStorage.getItem(`lang`)||`uz`,w=`home`,T=h();function E(t){return e[C][t]||t}function D(e){C=e,localStorage.setItem(`lang`,e),q()}function O(e){w=e,window.scrollTo(0,0),q()}function k(e){return e.split(` `).map(e=>e[0]).join(``).toUpperCase().slice(0,2)}function A(e){let t=[[`#5BA8D0`,`#E8F4FD`],[`#67B99A`,`#E8F6F1`],[`#7ECFC0`,`#E5F8F5`],[`#5B8DD0`,`#EBF2FD`],[`#9B8AC4`,`#F0EDF9`],[`#D08B5B`,`#FDF1E8`]];return t[e%t.length]}function j(){return`
  <nav class="navbar" id="navbar">
    <div class="nav-container">
      <div class="nav-brand" data-page="home">
        <div class="brand-icon">✦</div>
        <span>BabyTouch</span>
      </div>
      <button class="burger" id="burgerBtn" aria-label="menu">
        <span></span><span></span><span></span>
      </button>
      <div class="nav-links" id="navLinks">
        ${[{key:`home`,label:E(`nav_home`)},{key:`services`,label:E(`nav_services`)},{key:`prices`,label:E(`nav_prices`)},{key:`staff`,label:E(`nav_staff`)},{key:`booking`,label:E(`nav_booking`)}].map(e=>`
          <a class="nav-link ${w===e.key?`active`:``}" data-page="${e.key}" href="#">${e.label}</a>
        `).join(``)}
        ${T?.role===`admin`?`<a class="nav-link ${w===`admin`?`active`:``}" data-page="admin" href="#">${E(`nav_admin`)}</a>`:``}
        ${T?`
          <a class="nav-link ${w===`profile`?`active`:``}" data-page="profile" href="#">${E(`nav_profile`)}</a>
          <button class="btn-nav-logout" id="logoutBtn">${E(`nav_logout`)}</button>
        `:`
          <a class="nav-link ${w===`login`?`active`:``}" data-page="login" href="#">${E(`nav_login`)}</a>
        `}
        <div class="lang-switcher">
          ${[`uz`,`ru`,`en`].map(e=>`<button class="lang-btn ${C===e?`active`:``}" data-lang="${e}">${e.toUpperCase()}</button>`).join(``)}
        </div>
      </div>
    </div>
  </nav>`}function M(){return`
  <section class="hero" id="home">
    <div class="hero-bg">
      <div class="hero-blob blob1"></div>
      <div class="hero-blob blob2"></div>
      <div class="hero-blob blob3"></div>
    </div>
    <div class="hero-content">
      <div class="hero-badge animate-fade-in">🌿 Professional Massaj Markazi</div>
      <h1 class="hero-title animate-fade-in-up">
        ${E(`hero_title`)}<br/>
        <span class="gradient-text">${E(`hero_title2`)}</span>
      </h1>
      <p class="hero-subtitle animate-fade-in-up">${E(`hero_subtitle`)}</p>
      <div class="hero-actions animate-fade-in-up">
        <button class="btn-primary" data-page="booking">${E(`hero_btn_book`)}</button>
        <button class="btn-secondary" data-page="services">${E(`hero_btn_services`)}</button>
      </div>
      <div class="hero-stats animate-fade-in-up">
        <div class="stat-item">
          <span class="stat-number">500+</span>
          <span class="stat-label">${E(`hero_stat_clients`)}</span>
        </div>
        <div class="stat-divider"></div>
        <div class="stat-item">
          <span class="stat-number">6</span>
          <span class="stat-label">${E(`hero_stat_workers`)}</span>
        </div>
        <div class="stat-divider"></div>
        <div class="stat-item">
          <span class="stat-number">5+</span>
          <span class="stat-label">${E(`hero_stat_years`)}</span>
        </div>
      </div>
    </div>
    <div class="hero-image animate-slide-in">
      <div class="hero-img-frame">
        <img src="/hero_massage.png" alt="Massaj markazi" />
        <div class="hero-img-badge">
          <span>✓</span> Sertifikatlangan
        </div>
      </div>
    </div>
  </section>

  <section class="section services-section" id="services">
    <div class="container">
      <div class="section-header">
        <span class="section-tag">Xizmatlar</span>
        <h2 class="section-title">${E(`services_title`)}</h2>
        <p class="section-sub">${E(`services_subtitle`)}</p>
      </div>
      <div class="services-grid">
        <div class="service-card animate-card">
          <div class="service-img-wrap">
            <img src="/baby_massage.png" alt="Baby massage" class="service-img"/>
            <div class="service-img-overlay"><span>👶</span></div>
          </div>
          <div class="service-body">
            <h3>${E(`service_baby_title`)}</h3>
            <p>${E(`service_baby_desc`)}</p>
            <div class="service-tags">
              <span class="tag">2 oy – 6 yosh</span>
              <span class="tag">Sertifikatlangan</span>
            </div>
            <button class="btn-service" data-page="booking">${E(`hero_btn_book`)}</button>
          </div>
        </div>
        <div class="service-card animate-card">
          <div class="service-img-wrap">
            <img src="/women_massage.png" alt="Women massage" class="service-img"/>
            <div class="service-img-overlay"><span>🌸</span></div>
          </div>
          <div class="service-body">
            <h3>${E(`service_women_title`)}</h3>
            <p>${E(`service_women_desc`)}</p>
            <div class="service-tags">
              <span class="tag">Barcha yoshdagi ayollar</span>
              <span class="tag">Professional</span>
            </div>
            <button class="btn-service" data-page="booking">${E(`hero_btn_book`)}</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section prices-section" id="prices">
    <div class="container">
      <div class="section-header">
        <span class="section-tag">Narxlar</span>
        <h2 class="section-title">${E(`prices_title`)}</h2>
        <p class="section-sub">${E(`prices_subtitle`)}</p>
      </div>
      <div class="prices-grid">
        <div class="price-card animate-card">
          <div class="price-card-header baby-header">
            <div class="price-icon">👶</div>
            <h3>${E(`prices_baby`)}</h3>
          </div>
          <ul class="price-list">
            <li><span>2 oydan 1 yoshgacha</span><strong>70 000 ${E(`price_currency`)}</strong></li>
            <li><span>1 yoshdan 3 yoshgacha</span><strong>80 000 ${E(`price_currency`)}</strong></li>
            <li><span>4 yoshdan 6 yoshgacha</span><strong>90 000 ${E(`price_currency`)}</strong></li>
            <li class="divider-li"></li>
            <li><span>Parafin</span><strong>15 000 ${E(`price_currency`)}</strong></li>
            <li><span>Elektrofarez</span><strong>15 000 ${E(`price_currency`)}</strong></li>
            <li><span>Gidrovanna</span><strong>70 000 ${E(`price_currency`)}</strong></li>
          </ul>
          <div class="price-note">Kuniga ${E(`price_per_day`)}</div>
        </div>
        <div class="price-card price-featured animate-card">
          <div class="price-card-header women-header">
            <div class="price-icon">🌸</div>
            <h3>${E(`prices_women`)}</h3>
          </div>
          <ul class="price-list">
            <li><span>Boshdan belgacha</span><strong>80 000 ${E(`price_currency`)}</strong></li>
            <li><span>Oyoq massaji</span><strong>80 000 ${E(`price_currency`)}</strong></li>
            <li><span>Umumiy massaj</span><strong>200 000 ${E(`price_currency`)}</strong></li>
            <li><span>Bosh massaji</span><strong>80 000 ${E(`price_currency`)}</strong></li>
            <li><span>Bankali massaj</span><strong>80 000 ${E(`price_currency`)}</strong></li>
            <li><span>Ozdiruvchi massaj</span><strong>200 000 ${E(`price_currency`)}</strong></li>
          </ul>
          <div class="price-note">Kuniga ${E(`price_per_day`)}</div>
        </div>
      </div>
    </div>
  </section>

  <section class="section staff-preview-section">
    <div class="container">
      <div class="section-header">
        <span class="section-tag">Jamoa</span>
        <h2 class="section-title">${E(`staff_title`)}</h2>
        <p class="section-sub">${E(`staff_subtitle`)}</p>
      </div>
      ${N(!0)}
      <div style="text-align:center;margin-top:2rem">
        <button class="btn-primary" data-page="staff">Barchasini ko'rish</button>
      </div>
    </div>
  </section>

  ${K()}`}function N(e=!1){let t=l();return`
  <div class="staff-grid">
    ${(e?t.slice(0,4):t).map(e=>{let[t,n]=A(e.id),r=S(e),i=x(e.courseStartDate);return`
      <div class="staff-card animate-card">
        <div class="staff-avatar" style="background:${n}">
          ${e.photo?`<img src="${e.photo}" alt="${e.name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%"/>`:`<span class="avatar-initials" style="color:${t}">${k(e.name)}</span>`}
          <div class="staff-status-dot ${e.status===`free`?`dot-free`:`dot-busy`}"></div>
        </div>
        <h4 class="staff-name">${e.name}</h4>
        <p class="staff-exp">⭐ ${e.experience} ${E(`staff_experience`)}</p>
        <div class="staff-badge ${e.status===`free`?`badge-free`:`badge-busy`}">
          ${e.status===`free`?E(`staff_free`):E(`staff_busy`)}
        </div>
        <div class="course-info">
          <span class="course-days">📅 Kurs: ${r} kun qoldi</span>
          <span class="course-end">Tugaydi: ${i}</span>
        </div>
        <button class="btn-staff-book" data-page="booking" data-worker="${e.id}">${E(`staff_book`)}</button>
      </div>`}).join(``)}
  </div>`}function P(){return`
  <div class="page-hero">
    <div class="container">
      <h1 class="page-title">${E(`staff_title`)}</h1>
      <p class="page-sub">${E(`staff_subtitle`)}</p>
    </div>
  </div>
  <section class="section">
    <div class="container">
      ${N(!1)}
    </div>
  </section>
  ${K()}`}var F=null,I=null;function L(){let e=l(),t=e.find(e=>e.id===F),n=t?t.timeSlots.filter(e=>e.enabled&&!e.booked):[],r={};return n.forEach(e=>{r[e.date]||(r[e.date]=[]),r[e.date].push(e)}),`
  <div class="page-hero">
    <div class="container">
      <h1 class="page-title">${E(`booking_title`)}</h1>
      <p class="page-sub">${E(`booking_subtitle`)}</p>
    </div>
  </div>
  <section class="section">
    <div class="container">
      <div class="booking-layout">
        <div class="booking-step">
          <div class="step-num">1</div>
          <h3>${E(`booking_select_worker`)}</h3>
          <div class="booking-workers-list">
            ${e.map(e=>{let[t,n]=A(e.id),r=S(e);return`
              <div class="booking-worker-item ${F===e.id?`selected`:``}" data-select-worker="${e.id}">
                <div class="bw-avatar" style="background:${n}">
                  ${e.photo?`<img src="${e.photo}" alt="${e.name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%"/>`:`<span style="color:${t};font-weight:700;font-size:1rem">${k(e.name)}</span>`}
                </div>
                <div class="bw-info">
                  <span class="bw-name">${e.name}</span>
                  <span class="bw-exp">${e.experience} ${E(`staff_experience`)} · 📅 ${r} kun</span>
                </div>
                <div class="bw-badge ${e.status===`free`?`badge-free`:`badge-busy`}">
                  ${e.status===`free`?E(`staff_free`):E(`staff_busy`)}
                </div>
              </div>`}).join(``)}
          </div>
        </div>

        <div class="booking-step ${F?``:`step-disabled`}">
          <div class="step-num">2</div>
          <h3>${E(`booking_select_time`)}</h3>
          ${F?n.length===0?`<p class="step-hint">${E(`booking_no_slots`)}</p>`:`<div class="slots-by-date">
              ${Object.keys(r).map(e=>`
                <div class="date-group">
                  <div class="date-label">📅 ${e}</div>
                  <div class="slots-grid">
                    ${r[e].map(e=>`
                      <button class="slot-btn ${I===e.id?`slot-selected`:``}" data-slot="${e.id}">
                        <span class="slot-time">🕐 ${e.time}</span>
                      </button>`).join(``)}
                  </div>
                </div>`).join(``)}
            </div>`:`<p class="step-hint">Avval mutaxassis tanlang</p>`}
        </div>

        <div class="booking-step ${I?``:`step-disabled`}">
          <div class="step-num">3</div>
          <h3>Ma'lumotlaringiz</h3>
          <div class="booking-form">
            <div class="form-group">
              <label>${E(`booking_your_name`)}</label>
              <input type="text" id="bookingName" placeholder="${E(`booking_your_name`)}" />
            </div>
            <div class="form-group">
              <label>${E(`booking_your_phone`)}</label>
              <input type="tel" id="bookingPhone" placeholder="+998 90 123 45 67" />
            </div>
            <button class="btn-primary btn-full" id="confirmBookingBtn" ${I?``:`disabled`}>
              ${E(`booking_confirm`)}
            </button>
          </div>
        </div>
      </div>
      <div id="bookingSuccess" class="booking-success hidden">
        <div class="success-icon">✓</div>
        <h3>${E(`booking_success`)}</h3>
      </div>
    </div>
  </section>
  ${K()}`}var R=`login`,z=`client`;function B(){return`
  <div class="auth-wrapper">
    <div class="auth-card animate-fade-in">
      <div class="auth-logo">✦</div>
      <div class="auth-tabs">
        <button class="auth-tab ${R===`login`?`active`:``}" data-auth-tab="login">${E(`auth_login_tab`)}</button>
        <button class="auth-tab ${R===`register`?`active`:``}" data-auth-tab="register">${E(`auth_register_tab`)}</button>
      </div>
      
      <div id="authError" class="form-error hidden"></div>

      ${R===`login`?`
        <h2>${E(`login_title`)}</h2>
        <div class="form-group">
          <label>${E(`login_username`)}</label>
          <input type="text" id="loginUser" placeholder="${E(`login_username`)}" />
        </div>
        <div class="form-group">
          <label>${E(`login_password`)}</label>
          <input type="password" id="loginPass" placeholder="${E(`login_password`)}" />
        </div>
        <button class="btn-primary btn-full" id="loginBtn">${E(`login_btn`)}</button>
      `:`
        <h2>${E(`auth_register_tab`)}</h2>
        <div class="auth-role-select">
          <label class="radio-label">
            <input type="radio" name="authRole" value="client" ${z===`client`?`checked`:``} />
            ${E(`auth_role_client`)}
          </label>
          <label class="radio-label">
            <input type="radio" name="authRole" value="worker" ${z===`worker`?`checked`:``} />
            ${E(`auth_role_worker`)}
          </label>
        </div>

        <div class="form-group">
          <label>${E(`auth_name`)}</label>
          <input type="text" id="regName" placeholder="${E(`auth_name`)}" />
        </div>
        ${z===`client`?`
          <div class="form-group">
            <label>${E(`auth_phone`)}</label>
            <input type="tel" id="regPhone" placeholder="+998 90 123 45 67" />
          </div>
        `:`
          <div class="form-group">
            <label>${E(`auth_exp`)}</label>
            <input type="number" id="regExp" placeholder="Misol uchun: 3" />
          </div>
        `}
        <div class="form-group">
          <label>${E(`login_username`)}</label>
          <input type="text" id="regUser" placeholder="${E(`login_username`)}" />
        </div>
        <div class="form-group">
          <label>${E(`login_password`)}</label>
          <input type="password" id="regPass" placeholder="${E(`login_password`)}" />
        </div>
        <button class="btn-primary btn-full" id="registerBtn">${E(`auth_register_btn`)}</button>
      `}

      ${R===`login`?`
      <div class="login-hints" style="margin-top:1rem; font-size:0.8rem; color:#666">
        <p>Admin: admin / admin123 | Shahnoza: shahnoza / shahnoza123</p>
      </div>`:``}
    </div>
  </div>`}function V(){if(!T)return O(`login`),``;let e=p(),n=[];if(T.role===`client`)return n=e.filter(e=>e.clientName===T.name),`
    <div class="page-hero">
      <div class="container">
        <h1 class="page-title">${E(`profile_title`)}</h1>
      </div>
    </div>
    <section class="section">
      <div class="container">
        <div class="profile-layout" style="grid-template-columns: 1fr;">
          <div class="profile-section-card">
            <h3>👤 Mijoz: ${T.name}</h3>
            <p>Telefon: ${T.phone}</p>
          </div>
          <div class="profile-section-card">
            <h3>📋 Mening bronlarim (${n.length})</h3>
            ${n.length===0?`<p class="empty-hint">Sizda hali bronlar mavjud emas</p>`:`<div class="bookings-list">
                ${n.map(e=>{let t=l().find(t=>t.id===e.workerId);return`
                  <div class="booking-item">
                    <div><strong>Mutaxassis: ${t?t.name:`?`}</strong></div>
                    <div>📅 ${e.date} ${e.time}</div>
                  </div>`}).join(``)}
              </div>`}
          </div>
        </div>
      </div>
    </section>
    ${K()}`;let r=l().find(e=>e.id===T.id);if(!r)return O(`home`),``;let[i,a]=A(r.id);n=e.filter(e=>e.workerId===r.id);let o=S(r),s=x(r.courseStartDate);return`
  <div class="page-hero">
    <div class="container">
      <h1 class="page-title">${E(`profile_title`)}</h1>
    </div>
  </div>
  <section class="section">
    <div class="container">
      <div class="profile-layout">
        <div class="profile-card animate-card">
          <div class="profile-avatar-wrap">
            <div class="profile-avatar" style="background:${a}">
              ${r.photo?`<img src="${r.photo}" alt="${r.name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%" />`:`<span class="avatar-initials-lg" style="color:${i}">${k(r.name)}</span>`}
            </div>
            <label class="upload-btn" for="photoUpload">📷 ${E(`profile_upload_photo`)}</label>
            <input type="file" id="photoUpload" accept="image/*" style="display:none" />
          </div>

          <!-- Course progress -->
          <div class="course-card">
            <div class="course-card-row">
              <span>📅 Kurs boshlanishi</span>
              <strong>${r.courseStartDate}</strong>
            </div>
            <div class="course-card-row">
              <span>🏁 Kurs tugashi</span>
              <strong>${s}</strong>
            </div>
            <div class="course-card-row">
              <span>⏳ Qolgan kunlar</span>
              <strong class="${o<=2?`text-danger`:`text-success`}">${o} kun</strong>
            </div>
            <div class="course-progress-bar">
              <div class="course-progress-fill" style="width: ${Math.min(100,(10-o)/10*100)}%"></div>
            </div>
            <p class="course-note">* Yakshanba dam olish kuni. 10 ish kunidan so'ng vaqtlar avtomatik yangilanadi.</p>
          </div>

          <div class="form-group">
            <label>${E(`profile_name`)}</label>
            <input type="text" id="profileName" value="${r.name}" />
          </div>
          <div class="form-group">
            <label>${E(`profile_experience`)}</label>
            <input type="number" id="profileExp" value="${r.experience}" min="0" />
          </div>
          <div class="form-group">
            <label>${E(`profile_status`)}</label>
            <div class="status-toggle">
              <button class="status-btn ${r.status===`free`?`active-free`:``}" id="setFreeBtn">${E(`free`)}</button>
              <button class="status-btn ${r.status===`busy`?`active-busy`:``}" id="setBusyBtn">${E(`busy`)}</button>
            </div>
          </div>
          <button class="btn-primary btn-full" id="saveProfileBtn">${E(`profile_save`)}</button>
          <div id="profileSaved" class="save-success hidden">✓ ${E(`profile_saved`)}</div>
        </div>

        <div class="profile-right">
          <div class="profile-section-card">
            <div class="section-header-row">
              <h3>🕐 ${E(`profile_timeslots`)} (${r.timeSlots.filter(e=>e.enabled&&!e.booked).length} bo'sh)</h3>
              <button class="btn-add-slot" id="addSlotBtn">+ ${E(`profile_add_slot`)}</button>
            </div>
            <div id="addSlotForm" class="add-slot-form hidden">
              <input type="date" id="slotDate" min="${t(new Date)}" />
              <select id="slotTime">
                ${[`08:00`,`09:00`,`10:00`,`11:00`,`12:00`,`13:00`,`14:00`,`15:00`,`16:00`,`17:00`,`18:00`].map(e=>`<option value="${e}">${e}</option>`).join(``)}
              </select>
              <button class="btn-sm-primary" id="saveSlotBtn">Qo'shish</button>
            </div>
            <div class="slots-list" id="slotsList">
              ${r.timeSlots.length===0?`<p class="empty-hint">Vaqt yo'q</p>`:r.timeSlots.map(e=>`
                <div class="slot-item ${e.booked?`slot-booked`:e.enabled?``:`slot-disabled`}">
                  <div class="slot-info">
                    <span class="slot-date-text">${e.date}</span>
                    <span class="slot-time-text">🕐 ${e.time}</span>
                    ${e.booked?`<span class="slot-tag booked">Bron</span>`:``}
                  </div>
                  <div class="slot-actions">
                    <button class="toggle-slot ${e.enabled?`btn-disable`:`btn-enable`}" data-slot-id="${e.id}" ${e.booked?`disabled`:``}>
                      ${e.enabled?E(`profile_slot_disable`):E(`profile_slot_enable`)}
                    </button>
                    <button class="delete-slot btn-del" data-slot-id="${e.id}" ${e.booked?`disabled`:``}>🗑</button>
                  </div>
                </div>`).join(``)}
            </div>
          </div>

          <div class="profile-section-card">
            <h3>📋 ${E(`profile_bookings`)} (${e.length})</h3>
            ${e.length===0?`<p class="empty-hint">Bronlar yo'q</p>`:`<div class="bookings-list">
                ${e.map(e=>`
                  <div class="booking-item">
                    <div><strong>${e.clientName}</strong></div>
                    <div>📞 ${e.clientPhone}</div>
                    <div>📅 ${e.date} ${e.time}</div>
                  </div>`).join(``)}
              </div>`}
          </div>
        </div>
      </div>
    </div>
  </section>
  ${K()}`}var H=`workers`,U=null,W=!1;function G(){if(!T||T.role!==`admin`)return O(`login`),``;let e=l(),t=p();return`
  <div class="page-hero">
    <div class="container">
      <h1 class="page-title">${E(`admin_title`)}</h1>
    </div>
  </div>
  <section class="section">
    <div class="container">
      <div class="admin-tabs">
        <button class="admin-tab ${H===`workers`?`active`:``}" data-tab="workers">👥 ${E(`admin_workers`)} (${e.length})</button>
        <button class="admin-tab ${H===`bookings`?`active`:``}" data-tab="bookings">📋 ${E(`admin_bookings`)} (${t.length})</button>
      </div>

      ${H===`workers`?`
        <div class="admin-toolbar">
          <button class="btn-primary" id="toggleAddWorkerBtn">+ ${E(`admin_add_worker`)}</button>
        </div>

        ${W?`
        <div class="admin-form-card animate-fade-in">
          <h3>${E(U?`admin_edit`:`admin_add_worker`)}</h3>
          <div class="admin-form-grid">
            <div class="form-group">
              <label>${E(`admin_name`)}</label>
              <input type="text" id="af_name" value="${U&&e.find(e=>e.id===U)?.name||``}" placeholder="Ism familiya" />
            </div>
            <div class="form-group">
              <label>${E(`admin_username`)}</label>
              <input type="text" id="af_user" value="${U&&e.find(e=>e.id===U)?.username||``}" placeholder="login" />
            </div>
            <div class="form-group">
              <label>${E(`admin_password`)}</label>
              <input type="password" id="af_pass" placeholder="parol" />
            </div>
            <div class="form-group">
              <label>${E(`admin_experience`)}</label>
              <input type="number" id="af_exp" value="${U&&e.find(e=>e.id===U)?.experience||0}" min="0" />
            </div>
          </div>
          ${U?``:`<p class="admin-note">⚡ Yangi xodim uchun 10 kunlik vaqtlar avtomatik yaratiladi.</p>`}
          <div class="admin-form-actions">
            <button class="btn-primary" id="saveWorkerBtn">${E(`admin_save`)}</button>
            <button class="btn-secondary" id="cancelWorkerBtn">${E(`admin_cancel`)}</button>
          </div>
        </div>`:``}

        <div class="admin-workers-table">
          ${e.map(e=>{let[t,n]=A(e.id),r=S(e),i=x(e.courseStartDate);return`
            <div class="admin-worker-row">
              <div class="admin-worker-info">
                <div class="admin-avatar" style="background:${n}">
                  ${e.photo?`<img src="${e.photo}" alt="${e.name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%"/>`:`<span style="color:${t};font-weight:700">${k(e.name)}</span>`}
                </div>
                <div>
                  <div class="admin-worker-name">${e.name}</div>
                  <div class="admin-worker-meta">
                    @${e.username} · ${e.experience} yil ·
                    <span class="kurs-badge">📅 Kurs: ${r} kun qoldi (tugaydi: ${i})</span>
                  </div>
                </div>
              </div>
              <div class="admin-worker-controls">
                <div class="admin-status-toggle">
                  <button class="status-btn-sm ${e.status===`free`?`active-free`:``}" data-set-status="${e.id}" data-status="free">${E(`free`)}</button>
                  <button class="status-btn-sm ${e.status===`busy`?`active-busy`:``}" data-set-status="${e.id}" data-status="busy">${E(`busy`)}</button>
                </div>
                <button class="btn-edit" data-edit-worker="${e.id}">✎ ${E(`admin_edit`)}</button>
                <button class="btn-delete" data-delete-worker="${e.id}">🗑 ${E(`admin_delete`)}</button>
              </div>
            </div>`}).join(``)}
        </div>
      `:`
        <div class="bookings-table">
          ${t.length===0?`<p class="empty-hint">${E(`admin_no_bookings`)}</p>`:t.map(t=>{let n=e.find(e=>e.id===t.workerId);return`
              <div class="booking-row">
                <div class="booking-col"><strong>${t.clientName}</strong><br/><small>📞 ${t.clientPhone}</small></div>
                <div class="booking-col">${n?n.name:`–`}</div>
                <div class="booking-col">📅 ${t.date} ${t.time}</div>
              </div>`}).join(``)}
        </div>
      `}
    </div>
  </section>
  ${K()}`}function K(){return`
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="brand-icon">✦</div>
          <span>BabyTouch</span>
          <p>${E(`footer_text`)}</p>
        </div>
        <div class="footer-col">
          <h4>${E(`footer_contact`)}</h4>
          <p>📍 ${E(`footer_address`)}</p>
          <p>📞 ${E(`footer_phone`)}</p>
          <p>⏰ ${E(`footer_hours`)}</p>
        </div>
        <div class="footer-col">
          <h4>Tezkor havolalar</h4>
          <a href="#" data-page="home">Bosh sahifa</a>
          <a href="#" data-page="services">Xizmatlar</a>
          <a href="#" data-page="prices">Narxlar</a>
          <a href="#" data-page="booking">Bron qilish</a>
        </div>
      </div>
      <div class="footer-bottom">
        <p>${E(`footer_text`)}</p>
      </div>
    </div>
  </footer>`}function q(){let e=document.getElementById(`app`),t=``;w===`home`||w===`services`||w===`prices`?t=M():w===`staff`?t=P():w===`booking`?t=L():w===`login`?t=B():w===`profile`?t=V():w===`admin`&&(t=G()),e.innerHTML=j()+`<main>${t}</main>`,Y(),J()}function J(){(w===`services`||w===`prices`)&&setTimeout(()=>{let e=document.getElementById(w);e&&e.scrollIntoView({behavior:`smooth`})},100)}function Y(){document.querySelectorAll(`[data-page]`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.page;n===`booking`&&e.dataset.worker&&(F=parseInt(e.dataset.worker),I=null),O(n),document.getElementById(`navLinks`)?.classList.remove(`open`)})}),document.querySelectorAll(`[data-lang]`).forEach(e=>{e.addEventListener(`click`,()=>D(e.dataset.lang))}),document.getElementById(`burgerBtn`)?.addEventListener(`click`,()=>{document.getElementById(`navLinks`)?.classList.toggle(`open`)}),document.getElementById(`logoutBtn`)?.addEventListener(`click`,()=>{T=null,g(null),O(`home`)}),window.onscroll=()=>{let e=document.getElementById(`navbar`);e&&e.classList.toggle(`scrolled`,window.scrollY>50)},document.querySelectorAll(`[data-auth-tab]`).forEach(e=>{e.addEventListener(`click`,()=>{R=e.dataset.authTab,q()})}),document.querySelectorAll(`input[name="authRole"]`).forEach(e=>{e.addEventListener(`change`,e=>{z=e.target.value,q()})}),document.getElementById(`loginBtn`)?.addEventListener(`click`,t),document.getElementById(`loginPass`)?.addEventListener(`keydown`,e=>{e.key===`Enter`&&t()});function e(e){let t=document.getElementById(`authError`);t&&(t.textContent=e,t.classList.remove(`hidden`))}function t(){let t=document.getElementById(`loginUser`)?.value.trim(),n=document.getElementById(`loginPass`)?.value.trim(),r=_(t,n);r?(T=r,O(r.role===`admin`?`admin`:`profile`)):e(E(`login_error`))}document.getElementById(`registerBtn`)?.addEventListener(`click`,()=>{let t=document.getElementById(`regName`)?.value.trim(),n=document.getElementById(`regUser`)?.value.trim(),r=document.getElementById(`regPass`)?.value.trim();if(!t||!n||!r){e(`Barcha maydonlarni to'ldiring`);return}let i=null;if(z===`client`){let e=document.getElementById(`regPhone`)?.value.trim();i=b({name:t,phone:e,username:n,password:r})}else{let e=document.getElementById(`regExp`)?.value.trim();i=y({name:t,username:n,password:r,experience:e})}i?(T=_(i.username,i.password),O(`profile`)):e(`Bu login allaqachon band!`)}),document.querySelectorAll(`[data-select-worker]`).forEach(e=>{e.addEventListener(`click`,()=>{F=parseInt(e.dataset.selectWorker),I=null,q()})}),document.querySelectorAll(`[data-slot]`).forEach(e=>{e.addEventListener(`click`,()=>{I=parseInt(e.dataset.slot),q()})}),document.getElementById(`confirmBookingBtn`)?.addEventListener(`click`,()=>{let e=document.getElementById(`bookingName`)?.value.trim(),t=document.getElementById(`bookingPhone`)?.value.trim();if(!e||!t||!F||!I){alert(E(`booking_fill_all`));return}let n=l().find(e=>e.id===F)?.timeSlots.find(e=>e.id===I);n&&(v({workerId:F,slotId:I,clientName:e,clientPhone:t,date:n.date,time:n.time}),document.querySelector(`.booking-layout`).style.display=`none`,document.getElementById(`bookingSuccess`)?.classList.remove(`hidden`),F=null,I=null,setTimeout(()=>{O(T?.role===`client`?`profile`:`home`)},2500))}),document.getElementById(`photoUpload`)?.addEventListener(`change`,function(){let e=this.files[0];if(!e)return;let t=new FileReader;t.onload=e=>{let t=l(),n=t.findIndex(e=>e.id===T.id);n!==-1&&(t[n].photo=e.target.result,u(t),T={...T,photo:e.target.result},g(T),q())},t.readAsDataURL(e)}),document.getElementById(`saveProfileBtn`)?.addEventListener(`click`,()=>{let e=document.getElementById(`profileName`)?.value.trim(),t=parseInt(document.getElementById(`profileExp`)?.value),n=l(),r=n.findIndex(e=>e.id===T.id);r!==-1&&(n[r].name=e,n[r].experience=t,u(n),T={...T,name:e,experience:t},g(T),document.getElementById(`profileSaved`)?.classList.remove(`hidden`),setTimeout(()=>document.getElementById(`profileSaved`)?.classList.add(`hidden`),2e3))}),document.getElementById(`setFreeBtn`)?.addEventListener(`click`,()=>n(`free`)),document.getElementById(`setBusyBtn`)?.addEventListener(`click`,()=>n(`busy`));function n(e){let t=l(),n=t.findIndex(e=>e.id===T.id);n!==-1&&(t[n].status=e,u(t),T={...T,status:e},g(T),q())}document.getElementById(`addSlotBtn`)?.addEventListener(`click`,()=>{document.getElementById(`addSlotForm`)?.classList.toggle(`hidden`)}),document.getElementById(`saveSlotBtn`)?.addEventListener(`click`,()=>{let e=document.getElementById(`slotDate`)?.value,t=document.getElementById(`slotTime`)?.value;if(!e||!t)return;let n=l(),r=n.findIndex(e=>e.id===T.id);r!==-1&&(n[r].timeSlots.push({id:Date.now(),date:e,time:t,enabled:!0,booked:!1}),u(n),q())}),document.querySelectorAll(`.toggle-slot`).forEach(e=>{e.addEventListener(`click`,()=>{let t=parseInt(e.dataset.slotId),n=l(),r=n.findIndex(e=>e.id===T.id);if(r!==-1){let e=n[r].timeSlots.findIndex(e=>e.id===t);e!==-1&&(n[r].timeSlots[e].enabled=!n[r].timeSlots[e].enabled),u(n),q()}})}),document.querySelectorAll(`.delete-slot`).forEach(e=>{e.addEventListener(`click`,()=>{let t=parseInt(e.dataset.slotId),n=l(),r=n.findIndex(e=>e.id===T.id);r!==-1&&(n[r].timeSlots=n[r].timeSlots.filter(e=>e.id!==t),u(n),q())})}),document.querySelectorAll(`[data-tab]`).forEach(e=>{e.addEventListener(`click`,()=>{H=e.dataset.tab,q()})}),document.getElementById(`toggleAddWorkerBtn`)?.addEventListener(`click`,()=>{W=!W,U=null,q()}),document.getElementById(`cancelWorkerBtn`)?.addEventListener(`click`,()=>{W=!1,U=null,q()}),document.getElementById(`saveWorkerBtn`)?.addEventListener(`click`,()=>{let e=document.getElementById(`af_name`)?.value.trim(),t=document.getElementById(`af_user`)?.value.trim(),n=document.getElementById(`af_pass`)?.value.trim(),r=parseInt(document.getElementById(`af_exp`)?.value)||0;if(!(!e||!t)){if(U){let i=l(),a=i.findIndex(e=>e.id===U);a!==-1&&(i[a].name=e,i[a].username=t,n&&(i[a].password=n),i[a].experience=r,u(i))}else{if(!n){alert(`Parolni kiriting`);return}y({name:e,username:t,password:n,experience:r})}W=!1,U=null,q()}}),document.querySelectorAll(`[data-edit-worker]`).forEach(e=>{e.addEventListener(`click`,()=>{U=parseInt(e.dataset.editWorker),W=!0,q()})}),document.querySelectorAll(`[data-delete-worker]`).forEach(e=>{e.addEventListener(`click`,()=>{confirm(E(`admin_confirm_delete`))&&(u(l().filter(t=>t.id!==parseInt(e.dataset.deleteWorker))),q())})}),document.querySelectorAll(`[data-set-status]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=parseInt(e.dataset.setStatus),n=e.dataset.status,r=l(),i=r.findIndex(e=>e.id===t);i!==-1&&(r[i].status=n,u(r),q())})})}q();